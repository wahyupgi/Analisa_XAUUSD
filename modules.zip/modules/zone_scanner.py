# -*- coding: utf-8 -*-
"""
modules/zone_scanner.py
Python-Only XAUUSD Zone Scanner & SMC Validation Engine.

Modul ini sepenuhnya independen dari AI / Gemini dan layanan cloud lainnya.
Seluruh deteksi, scoring, validasi, penggabungan, dan penolakan zona dilakukan
secara deterministik murni menggunakan Python berdasarkan data OHLCV/tick dari MT5.

Prinsip Utama:
- Kualitas > Kuantitas (Lebih baik menghasilkan 0 zona valid daripada zona berkualitas rendah).
- Zona utama HANYA berasal dari Order Block (OB) H4 dan H1 yang memiliki BOS jelas dan displacement memadai.
- Fair Value Gap (FVG) HANYA berfungsi sebagai konfirmasi kualitas OB (bukan generator zona mandiri).
- Liquidity Sweep berfungsi sebagai bukti pendukung (konfirmasi tambahan).
- Candle close digunakan untuk semua konfirmasi struktur; wick saja tidak dianggap breakout.
- Bebas look-ahead bias & repainting (hanya menggunakan candle yang sudah close).
"""

import math
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import List, Dict, Optional, Tuple, Any

import numpy as np
import pandas as pd

from modules.config import SYMBOL, TIMEFRAMES, SWING_N, RR_MIN
from modules.utils import wkt, _catat_error
from modules.mt5_conn import (
    ambil_data,
    pastikan_mt5_aktif,
    tambah_indikator,
)

# =============================================================================
# KONSTANTA & THRESHOLD ZONE SCANNER
# =============================================================================

MIN_DISPLACEMENT_ATR = 1.5      # Minimum cumulative impulse movement relative to ATR
MIN_FVG_ATR = 0.30              # Minimum FVG gap size relative to ATR
MAX_ZONE_WIDTH_ATR = 2.5        # Maximum zone width relative to ATR
MAX_ZONE_WIDTH_POINTS = 10.0    # Absolute maximum zone width in gold points
MIN_ZONE_WIDTH_POINTS = 0.4     # Minimum zone width in gold points
MAX_TOUCH_COUNT = 2             # Maximum touches before zone is deemed depleted/mitigated
MAX_ZONE_DISTANCE_ATR = 10.0    # Zones further than 10x ATR are ignored for active execution
SCORE_MIN_ACTIVE = 60.0         # Minimum score to be considered active
SCORE_GRADE_A_PLUS = 85.0
SCORE_GRADE_A = 75.0
SCORE_GRADE_B = 60.0


# =============================================================================
# DATA STRUCTURE: ZONE
# =============================================================================

@dataclass
class Zone:
    zone_id: str
    symbol: str
    timeframe: str                      # "H4" or "H1"
    zone_type: str                      # "DEMAND" or "SUPPLY"
    price_low: float
    price_high: float
    midpoint: float
    score: float                        # 0 - 100
    grade: str                          # "A+", "A", "B", "REJECTED"
    origin_bos: Dict[str, Any]          # Details of the BOS/CHoCH event
    fvg_confirmation: Optional[Dict[str, Any]] # Details of confirming FVG
    displacement_strength: float        # Displacement in multiples of ATR
    freshness: str                      # "FRESH", "TESTED_1X", "TESTED_2X", "MITIGATED", "INVALIDATED"
    touch_count: int
    liquidity_sweep_status: str         # "CONFIRMED_SWEEP_LOW", "CONFIRMED_SWEEP_HIGH", "NONE"
    invalidation_price: float           # Price invalidating the zone (low for DEMAND, high for SUPPLY)
    is_valid: bool
    rejection_reason: str
    ob_candle_time: Any = None
    bos_candle_time: Any = None
    sl_recommended: float = 0.0
    tp1_recommended: float = 0.0
    tp2_recommended: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)
    merged_from: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if isinstance(d.get("ob_candle_time"), (pd.Timestamp, datetime)):
            d["ob_candle_time"] = str(d["ob_candle_time"])
        if isinstance(d.get("bos_candle_time"), (pd.Timestamp, datetime)):
            d["bos_candle_time"] = str(d["bos_candle_time"])
        return d


# =============================================================================
# CORE SMC COMPUTATIONS (PURE PYTHON / NUMPY)
# =============================================================================

def detect_swings(df: pd.DataFrame, n: int = SWING_N) -> List[Dict[str, Any]]:
    """
    Identifikasi Swing High dan Swing Low tanpa look-ahead bias.
    Sebuah swing di candle i baru terkonfirmasi pada candle i + n.
    """
    if df is None or len(df) < 2 * n + 1:
        return []
    
    H = df["High"].values
    L = df["Low"].values
    idx = df.index
    swings = []
    
    total = len(df)
    for i in range(n, total - n):
        # Swing High
        if H[i] == np.max(H[i - n : i + n + 1]):
            swings.append({
                "idx": i,
                "type": "H",
                "price": float(H[i]),
                "time": idx[i],
                "confirmed_at": i + n,
            })
        # Swing Low
        if L[i] == np.min(L[i - n : i + n + 1]):
            swings.append({
                "idx": i,
                "type": "L",
                "price": float(L[i]),
                "time": idx[i],
                "confirmed_at": i + n,
            })
            
    swings.sort(key=lambda s: s["idx"])
    return swings


def detect_market_structure(df: pd.DataFrame, n: int = SWING_N) -> Tuple[List[Dict[str, Any]], int, List[Dict[str, Any]]]:
    """
    Deteksi Break of Structure (BOS) dan Change of Character (CHoCH).
    Syarat Utama:
    - Konfirmasi mutlak menggunakan candle CLOSE (bukan sekadar wick).
    - Membedakan bullish structure (HH-HL) dan bearish structure (LH-LL).
    - BOS = kelanjutan tren saat ini.
    - CHoCH = pembalikan arah tren.
    
    Mengembalikan: (events, current_trend, swings)
      events: list dict event struktur
      current_trend: 1 (Bullish), -1 (Bearish), 0 (Netral)
      swings: list swing terdeteksi
    """
    if df is None or len(df) < 2 * n + 1:
        return [], 0, []
        
    swings = detect_swings(df, n)
    C = df["Close"].values
    idx = df.index
    
    # Kelompokkan swing berdasarkan kapan swing tersebut terkonfirmasi (candle i + n)
    confirmed_map: Dict[int, List[Dict[str, Any]]] = {}
    for s in swings:
        conf_k = s["confirmed_at"]
        confirmed_map.setdefault(conf_k, []).append(s)
        
    last_high: Optional[Dict[str, Any]] = None
    last_low: Optional[Dict[str, Any]] = None
    trend = 0  # 1 = Bullish, -1 = Bearish, 0 = Netral
    events = []
    
    for k in range(len(df)):
        # Masukkan swing yang baru saja terkonfirmasi pada candle k
        for s in confirmed_map.get(k, []):
            if s["type"] == "H":
                last_high = s
            elif s["type"] == "L":
                last_low = s
                
        # Cek konfirmasi breakout oleh candle CLOSE
        # 1. Bullish breakout menembus last_high
        if last_high is not None and C[k] > last_high["price"]:
            tipe = "CHoCH" if trend == -1 else "BOS"
            origin_idx = last_low["idx"] if last_low else max(0, k - 30)
            events.append({
                "k": k,
                "time": idx[k],
                "tipe": tipe,
                "arah": "bull",
                "level": float(last_high["price"]),
                "origin_idx": origin_idx,
                "swing_idx": last_high["idx"],
                "swing_time": last_high["time"],
            })
            last_high = None  # Level sudah di-break
            trend = 1
            
        # 2. Bearish breakout menembus last_low
        elif last_low is not None and C[k] < last_low["price"]:
            tipe = "CHoCH" if trend == 1 else "BOS"
            origin_idx = last_high["idx"] if last_high else max(0, k - 30)
            events.append({
                "k": k,
                "time": idx[k],
                "tipe": tipe,
                "arah": "bear",
                "level": float(last_low["price"]),
                "origin_idx": origin_idx,
                "swing_idx": last_low["idx"],
                "swing_time": last_low["time"],
            })
            last_low = None  # Level sudah di-break
            trend = -1
            
    return events, trend, swings


def detect_liquidity_sweeps(df: pd.DataFrame, swings: List[Dict[str, Any]], lookback: int = 40) -> List[Dict[str, Any]]:
    """
    Deteksi Liquidity Sweep & Equal Highs/Lows (EQH/EQL):
    - Wick menembus level swing lama, namun candle CLOSE kembali ke dalam range.
    - Equal Highs / Equal Lows yang tersapu atau masih menjadi magnet likuiditas.
    """
    if df is None or len(df) < 2 * SWING_N + 1 or not swings:
        return []
        
    H = df["High"].values
    L = df["Low"].values
    C = df["Close"].values
    idx = df.index
    
    sweeps = []
    seen = set()
    start_k = max(0, len(df) - lookback)
    
    for k in range(start_k, len(df)):
        # Ambil swing yang sudah terkonfirmasi sebelum candle k
        cand_swings = [s for s in swings if s["confirmed_at"] < k]
        if not cand_swings:
            continue
            
        for s in cand_swings[-8:]:
            stype, p = s["type"], s["price"]
            key = (stype, round(p, 2), k)
            if key in seen:
                continue
                
            # Sweep High (Buy-Side Liquidity Grab)
            if stype == "H":
                if H[k] > p and C[k] <= p:
                    sweeps.append({
                        "k": k,
                        "time": idx[k],
                        "type": "SWEEP_HIGH",
                        "level": p,
                        "wick_extreme": float(H[k]),
                        "close_price": float(C[k]),
                        "swing_time": s["time"],
                        "description": f"Buy-Side Liquidity Sweep (High {p:.2f} disapu wick {H[k]:.2f}, close {C[k]:.2f})"
                    })
                    seen.add(key)
                    
            # Sweep Low (Sell-Side Liquidity Grab)
            elif stype == "L":
                if L[k] < p and C[k] >= p:
                    sweeps.append({
                        "k": k,
                        "time": idx[k],
                        "type": "SWEEP_LOW",
                        "level": p,
                        "wick_extreme": float(L[k]),
                        "close_price": float(C[k]),
                        "swing_time": s["time"],
                        "description": f"Sell-Side Liquidity Sweep (Low {p:.2f} disapu wick {L[k]:.2f}, close {C[k]:.2f})"
                    })
                    seen.add(key)
                    
    return sweeps


def detect_fvgs(df: pd.DataFrame, min_atr_mult: float = MIN_FVG_ATR) -> List[Dict[str, Any]]:
    """
    Deteksi Fair Value Gap (FVG) 3-candle pattern:
    - Bullish FVG: Low[i] > High[i-2], gap = Low[i] - High[i-2] >= min_atr_mult * ATR
    - Bearish FVG: High[i] < Low[i-2], gap = Low[i-2] - High[i] >= min_atr_mult * ATR
    - Melacak status mitigasi: UNTOUCHED, PARTIALLY_MITIGATED, FULLY_MITIGATED
    """
    if df is None or len(df) < 3:
        return []
        
    d = df.copy()
    if "ATR14" not in d.columns:
        d = tambah_indikator(d)
        
    atr = d["ATR14"].values
    H = d["High"].values
    L = d["Low"].values
    idx = d.index
    
    fvgs = []
    
    for i in range(2, len(d)):
        cur_atr = atr[i]
        if not np.isfinite(cur_atr) or cur_atr <= 0:
            continue
            
        threshold = min_atr_mult * cur_atr
        
        # Bullish FVG
        if L[i] > H[i - 2]:
            gap_size = L[i] - H[i - 2]
            if gap_size >= threshold:
                bawah, atas = float(H[i - 2]), float(L[i])
                subseq_lows = L[i + 1:] if i + 1 < len(d) else np.array([])
                
                if len(subseq_lows) > 0:
                    min_subseq = float(np.min(subseq_lows))
                    if min_subseq <= bawah:
                        status = "FULLY_MITIGATED"
                    elif min_subseq < atas:
                        status = "PARTIALLY_MITIGATED"
                    else:
                        status = "UNTOUCHED"
                else:
                    status = "UNTOUCHED"
                    
                fvgs.append({
                    "idx": i - 1, # Candle tengah pembentuk gap
                    "time": idx[i - 1],
                    "type": "BULLISH_FVG",
                    "price_low": bawah,
                    "price_high": atas,
                    "size_points": gap_size,
                    "size_atr": gap_size / cur_atr,
                    "status": status,
                })
                
        # Bearish FVG
        elif H[i] < L[i - 2]:
            gap_size = L[i - 2] - H[i]
            if gap_size >= threshold:
                bawah, atas = float(H[i]), float(L[i - 2])
                subseq_highs = H[i + 1:] if i + 1 < len(d) else np.array([])
                
                if len(subseq_highs) > 0:
                    max_subseq = float(np.max(subseq_highs))
                    if max_subseq >= atas:
                        status = "FULLY_MITIGATED"
                    elif max_subseq > bawah:
                        status = "PARTIALLY_MITIGATED"
                    else:
                        status = "UNTOUCHED"
                else:
                    status = "UNTOUCHED"
                    
                fvgs.append({
                    "idx": i - 1,
                    "time": idx[i - 1],
                    "type": "BEARISH_FVG",
                    "price_low": bawah,
                    "price_high": atas,
                    "size_points": gap_size,
                    "size_atr": gap_size / cur_atr,
                    "status": status,
                })
                
    return fvgs


def detect_order_blocks(
    df: pd.DataFrame,
    events: List[Dict[str, Any]],
    fvgs: List[Dict[str, Any]],
    sweeps: List[Dict[str, Any]],
    timeframe: str,
    max_events: int = 10
) -> Tuple[List[Zone], List[Zone]]:
    """
    Pencarian dan Evaluasi Order Block (OB) sebagai METODE PEMBENTUK ZONA UTAMA:
    
    Kriteria Pembentukan:
    - Bullish OB: Candle bearish terakhir sebelum impuls bullish yang menghasilkan BOS/CHoCH terkonfirmasi.
    - Bearish OB: Candle bullish terakhir sebelum impuls bearish yang menghasilkan BOS/CHoCH terkonfirmasi.
    - Impuls harus memiliki kekuatan displacement memadai (>= 1.5x ATR).
    - FVG harus relevan & bertumpuk/overlap dengan Order Block sebagai konfirmasi kualitas.
    - Evaluasi ketat status freshness, touch_count, dan invalidasi.
    
    Mengembalikan: (valid_zones, rejected_zones)
    """
    if df is None or len(df) < 2 * SWING_N + 1 or not events:
        return [], []
        
    d = df.copy()
    if "ATR14" not in d.columns:
        d = tambah_indikator(d)
        
    O = d["Open"].values
    H = d["High"].values
    L = d["Low"].values
    C = d["Close"].values
    atr = d["ATR14"].values
    idx = d.index
    
    valid_candidates: List[Zone] = []
    rejected_candidates: List[Zone] = []
    
    # Evaluasi event struktur terbaru
    eval_events = events[-max_events:]
    
    for ev in eval_events:
        k = ev["k"]                  # Index candle break BOS/CHoCH
        origin = ev["origin_idx"]    # Index swing origin
        arah = ev["arah"]            # "bull" atau "bear"
        tipe_ev = ev["tipe"]         # "BOS" atau "CHoCH"
        
        # Titik acuan leg: gunakan level swing yang di-break untuk mencari titik belok ekstrem
        start_leg = ev.get("swing_idx", origin)
        if start_leg >= k:
            start_leg = origin
        if start_leg >= k:
            continue
            
        cur_atr = float(atr[k]) if np.isfinite(atr[k]) and atr[k] > 0 else 2.0
        
        # 1. Tentukan candle Order Block (OB)
        if arah == "bull":
            # Cari titik terendah pada leg pergerakan
            m = start_leg + int(np.argmin(L[start_leg : k + 1]))
            # Cari candle bearish terakhir sebelum/pada titik terendah tersebut
            ob_idx = next((x for x in range(m, max(start_leg - 4, -1), -1) if C[x] < O[x]), m)
            ob_lo = float(L[ob_idx])
            ob_hi = float(H[ob_idx])
            zone_type = "DEMAND"
            
            # Hitung kekuatan displacement leg: dari OB low ke close breakout k
            displacement_pts = C[k] - ob_lo
            displacement_atr = displacement_pts / cur_atr if cur_atr > 0 else 0.0
            
        else: # bear
            # Cari titik tertinggi pada leg pergerakan
            m = start_leg + int(np.argmax(H[start_leg : k + 1]))
            # Cari candle bullish terakhir sebelum/pada titik tertinggi tersebut
            ob_idx = next((x for x in range(m, max(start_leg - 4, -1), -1) if C[x] > O[x]), m)
            ob_lo = float(L[ob_idx])
            ob_hi = float(H[ob_idx])
            zone_type = "SUPPLY"
            
            # Hitung kekuatan displacement leg: dari OB high ke close breakout k
            displacement_pts = ob_hi - C[k]
            displacement_atr = displacement_pts / cur_atr if cur_atr > 0 else 0.0
            
        zone_width = ob_hi - ob_lo
        midpoint = (ob_lo + ob_hi) / 2.0
        zone_id = f"ZONE_{timeframe}_{zone_type}_{int(idx[ob_idx].timestamp())}"
        
        # Invalidation level:
        # DEMAND: jika ada candle close di bawah ob_lo -> INVALID
        # SUPPLY: jika ada candle close di atas ob_hi -> INVALID
        inval_price = ob_lo if zone_type == "DEMAND" else ob_hi
        
        # 2. Cek apakah ada FVG konfirmasi yang relevan (dalam rentang waktu leg & overlap harga)
        fvg_conf = None
        target_fvg_type = "BULLISH_FVG" if zone_type == "DEMAND" else "BEARISH_FVG"
        
        # Cari FVG yang terbentuk antara ob_idx dan k + 2
        leg_fvgs = [
            f for f in fvgs
            if f["type"] == target_fvg_type
            and (ob_idx - 1 <= f["idx"] <= k + 3)
            and f["status"] != "FULLY_MITIGATED"
        ]
        
        # Periksa overlap harga FVG dengan OB (atau bertetangga dekat <= 0.25 ATR)
        best_fvg = None
        for f in leg_fvgs:
            overlap = (min(ob_hi, f["price_high"]) - max(ob_lo, f["price_low"]))
            if overlap > -0.25 * cur_atr:
                best_fvg = f
                break
                
        fvg_conf = best_fvg
        
        # 3. Cek riwayat sentuhan & invalidasi sejak BOS terbentuk (k+1 hingga candle terakhir)
        touch_count = 0
        is_invalidated = False
        rejection_reason = ""
        
        for x in range(k + 1, len(d)):
            if zone_type == "DEMAND":
                # Jika candle close di bawah batas bawah OB -> INVALID!
                if C[x] < ob_lo:
                    is_invalidated = True
                    rejection_reason = f"Zona telah invalid (Close {C[x]:.2f} < batas bawah {ob_lo:.2f})"
                    break
                # Jika harga menyentuh zona (Low <= ob_hi dan High >= ob_lo)
                if L[x] <= ob_hi and H[x] >= ob_lo:
                    # Hitung sentuhan unik (hindari menghitung candle beruntun di dalam zona sebagai sentuhan baru)
                    if x == k + 1 or not (L[x - 1] <= ob_hi and H[x - 1] >= ob_lo):
                        touch_count += 1
            else: # SUPPLY
                # Jika candle close di atas batas atas OB -> INVALID!
                if C[x] > ob_hi:
                    is_invalidated = True
                    rejection_reason = f"Zona telah invalid (Close {C[x]:.2f} > batas atas {ob_hi:.2f})"
                    break
                # Jika harga menyentuh zona (High >= ob_lo dan Low <= ob_hi)
                if H[x] >= ob_lo and L[x] <= ob_hi:
                    if x == k + 1 or not (H[x - 1] >= ob_lo and L[x - 1] <= ob_hi):
                        touch_count += 1
                        
        # Tentukan status freshness
        if is_invalidated:
            freshness = "INVALIDATED"
        elif touch_count == 0:
            freshness = "FRESH"
        elif touch_count == 1:
            freshness = "TESTED_1X"
        elif touch_count == 2:
            freshness = "TESTED_2X"
        else:
            freshness = "MITIGATED"
            
        # 4. Deteksi Liquidity Sweep sebelum pembentukan OB
        sweep_status = "NONE"
        relevant_sweeps = [
            s for s in sweeps
            if abs(s["k"] - ob_idx) <= 5
        ]
        if relevant_sweeps:
            if zone_type == "DEMAND" and any(s["type"] == "SWEEP_LOW" for s in relevant_sweeps):
                sweep_status = "CONFIRMED_SWEEP_LOW"
            elif zone_type == "SUPPLY" and any(s["type"] == "SWEEP_HIGH" for s in relevant_sweeps):
                sweep_status = "CONFIRMED_SWEEP_HIGH"
                
        # 5. Rekomendasi SL & TP berbasis struktur teknikal OB
        buffer_sl = max(1.8, round(0.8 * cur_atr, 2))
        if zone_type == "DEMAND":
            sl_rec = round(ob_lo - buffer_sl, 2)
            risk = max(2.0, midpoint - sl_rec)
            tp1_rec = round(midpoint + RR_MIN * risk, 2)
            tp2_rec = round(midpoint + 2.5 * risk, 2)
        else:
            sl_rec = round(ob_hi + buffer_sl, 2)
            risk = max(2.0, sl_rec - midpoint)
            tp1_rec = round(midpoint - RR_MIN * risk, 2)
            tp2_rec = round(midpoint - 2.5 * risk, 2)
            
        # 6. Filter Kualitas Mutlak (Mandatory Pass/Fail)
        reasons = []
        if is_invalidated:
            reasons.append(rejection_reason)
        if touch_count > MAX_TOUCH_COUNT:
            reasons.append(f"Zona sudah dimitigasi/disentuh terlalu sering ({touch_count}x > {MAX_TOUCH_COUNT}x)")
        if displacement_atr < MIN_DISPLACEMENT_ATR:
            reasons.append(f"Displacement tidak memadai ({displacement_atr:.2f}x ATR < {MIN_DISPLACEMENT_ATR:.2f}x)")
        if fvg_conf is None:
            reasons.append("Tidak ada konfirmasi FVG aktif/untouched yang relevan dengan OB")
        if zone_width > min(MAX_ZONE_WIDTH_POINTS, MAX_ZONE_WIDTH_ATR * cur_atr):
            reasons.append(f"Zona terlalu lebar ({zone_width:.2f} pt > batas toleransi)")
        if zone_width < MIN_ZONE_WIDTH_POINTS:
            reasons.append(f"Zona terlalu sempit/noise ({zone_width:.2f} pt < {MIN_ZONE_WIDTH_POINTS} pt)")
            
        is_mandat_ok = len(reasons) == 0
        final_rejection = "; ".join(reasons) if not is_mandat_ok else ""
        
        cand_zone = Zone(
            zone_id=zone_id,
            symbol=SYMBOL,
            timeframe=timeframe,
            zone_type=zone_type,
            price_low=round(ob_lo, 2),
            price_high=round(ob_hi, 2),
            midpoint=round(midpoint, 2),
            score=0.0,
            grade="REJECTED",
            origin_bos=ev,
            fvg_confirmation=fvg_conf,
            displacement_strength=round(displacement_atr, 2),
            freshness=freshness,
            touch_count=touch_count,
            liquidity_sweep_status=sweep_status,
            invalidation_price=round(inval_price, 2),
            is_valid=is_mandat_ok,
            rejection_reason=final_rejection,
            ob_candle_time=idx[ob_idx],
            bos_candle_time=idx[k],
            sl_recommended=sl_rec,
            tp1_recommended=tp1_rec,
            tp2_recommended=tp2_rec,
        )
        
        if is_mandat_ok:
            valid_candidates.append(cand_zone)
        else:
            rejected_candidates.append(cand_zone)
            
    return valid_candidates, rejected_candidates


# =============================================================================
# SCORING & GRADING SYSTEM (0 - 100)
# =============================================================================

def score_zone(
    zone: Zone,
    htf_bias_aligned: bool = True,
    htf_is_neutral: bool = False
) -> Zone:
    """
    Sistem Penilaian Zona Berbobot (0 - 100):
    1. Validitas Struktur dan BOS    : 25 poin
    2. Kualitas Displacement         : 20 poin
    3. Konfirmasi FVG                : 20 poin
    4. Freshness Zona                : 15 poin
    5. Konteks HTF                   : 10 poin
    6. Liquidity Sweep               : 10 poin
    
    Total Maksimum: 100 poin.
    Grade:
    - A+ : 85 - 100
    - A  : 75 - 84
    - B  : 60 - 74
    - Di bawah 60: REJECTED (tidak layak ditampilkan sebagai zona aktif).
    
    Catatan: Skor tidak boleh menggantikan syarat wajib.
    """
    if not zone.is_valid:
        zone.score = 0.0
        zone.grade = "REJECTED"
        return zone
        
    pts_struct = 0.0
    pts_disp = 0.0
    pts_fvg = 0.0
    pts_fresh = 0.0
    pts_htf = 0.0
    pts_sweep = 0.0
    
    # 1. Struktur & BOS (25 poin)
    ev_type = zone.origin_bos.get("tipe", "")
    if zone.timeframe == "H4":
        pts_struct = 25.0 if ev_type == "BOS" else 20.0
    else: # H1
        pts_struct = 20.0 if ev_type == "BOS" else 15.0
        
    # 2. Kualitas Displacement (20 poin)
    disp = zone.displacement_strength
    if disp >= 2.5:
        pts_disp = 20.0
    elif disp >= 2.0:
        pts_disp = 16.0
    elif disp >= 1.5:
        pts_disp = 12.0
    else:
        pts_disp = 0.0
        
    # 3. Konfirmasi FVG (20 poin)
    if zone.fvg_confirmation:
        f_stat = zone.fvg_confirmation.get("status", "")
        if f_stat == "UNTOUCHED":
            pts_fvg = 20.0
        elif f_stat == "PARTIALLY_MITIGATED":
            pts_fvg = 14.0
        else:
            pts_fvg = 8.0
    else:
        pts_fvg = 0.0
        
    # 4. Freshness Zona (15 poin)
    if zone.freshness == "FRESH":
        pts_fresh = 15.0
    elif zone.freshness == "TESTED_1X":
        pts_fresh = 8.0
    elif zone.freshness == "TESTED_2X":
        pts_fresh = 3.0
    else:
        pts_fresh = 0.0
        
    # 5. Konteks HTF (10 poin)
    if htf_bias_aligned:
        pts_htf = 10.0
    elif htf_is_neutral:
        pts_htf = 5.0
    else:
        pts_htf = 0.0
        
    # 6. Liquidity Sweep (10 poin)
    if zone.liquidity_sweep_status in ("CONFIRMED_SWEEP_LOW", "CONFIRMED_SWEEP_HIGH"):
        pts_sweep = 10.0
    else:
        pts_sweep = 0.0
        
    total_score = round(pts_struct + pts_disp + pts_fvg + pts_fresh + pts_htf + pts_sweep, 1)
    zone.score = total_score
    zone.score_breakdown = {
        "struktur_bos": pts_struct,
        "displacement": pts_disp,
        "fvg_konfirmasi": pts_fvg,
        "freshness": pts_fresh,
        "konteks_htf": pts_htf,
        "liquidity_sweep": pts_sweep,
    }
    
    # Penentuan Grade
    if total_score >= SCORE_GRADE_A_PLUS:
        zone.grade = "A+"
    elif total_score >= SCORE_GRADE_A:
        zone.grade = "A"
    elif total_score >= SCORE_GRADE_B:
        zone.grade = "B"
    else:
        zone.grade = "REJECTED"
        zone.is_valid = False
        zone.rejection_reason = f"Skor total ({total_score:.1f}) di bawah batas minimum kelayakan ({SCORE_MIN_ACTIVE})"
        
    return zone


# =============================================================================
# ZONE MERGING (PENGGABUNGAN ZONA OVERLAP)
# =============================================================================

def merge_overlapping_zones(zones: List[Zone]) -> List[Zone]:
    """
    Menggabungkan zona-zona yang:
    - Memiliki arah dan tipe sama (DEMAND vs DEMAND, SUPPLY vs SUPPLY)
    - Rentang harga saling overlap
    - Berasal dari konteks pergerakan harga yang sama
    
    Menghasilkan 1 zona konsolidasi berkualitas tinggi tanpa duplikasi.
    """
    if len(zones) <= 1:
        return zones
        
    # Urutkan berdasarkan tipe zona dan harga
    sorted_zones = sorted(zones, key=lambda z: (z.zone_type, z.price_low))
    merged: List[Zone] = []
    
    for z in sorted_zones:
        if not merged:
            merged.append(z)
            continue
            
        last = merged[-1]
        
        # Cek apakah tipe sama dan ada overlap harga
        if last.zone_type == z.zone_type:
            overlap_lo = max(last.price_low, z.price_low)
            overlap_hi = min(last.price_high, z.price_high)
            
            # Ada tumpang tindih harga
            if overlap_hi >= overlap_lo:
                # Gabungkan menjadi zona yang lebih presisi (ambil area overlap konsolidasi)
                # atau gabungkan rentang jika width tetap aman <= MAX_ZONE_WIDTH_POINTS
                new_lo = min(last.price_low, z.price_low)
                new_hi = max(last.price_high, z.price_high)
                
                # Jika rentang gabungan masih wajar
                if (new_hi - new_lo) <= MAX_ZONE_WIDTH_POINTS:
                    combined_lo = new_lo
                    combined_hi = new_hi
                else:
                    # Ambil perpotongan (confluence overlap) yang lebih presisi
                    combined_lo = overlap_lo
                    combined_hi = overlap_hi
                    
                combined_mid = round((combined_lo + combined_hi) / 2.0, 2)
                
                # Ambil skor tertinggi dan beri boost konfluensi multi-timeframe
                best_score = max(last.score, z.score)
                if last.timeframe != z.timeframe:
                    best_score = min(100.0, best_score + 5.0) # Bonus cross-TF confluence
                    
                # Tentukan grade baru
                if best_score >= SCORE_GRADE_A_PLUS:
                    new_grade = "A+"
                elif best_score >= SCORE_GRADE_A:
                    new_grade = "A"
                elif best_score >= SCORE_GRADE_B:
                    new_grade = "B"
                else:
                    new_grade = "REJECTED"
                    
                tf_label = f"{last.timeframe}+{z.timeframe}" if last.timeframe != z.timeframe else last.timeframe
                
                merged_ids = list(set(last.merged_from + z.merged_from + [last.zone_id, z.zone_id]))
                
                # Rekomendasi SL di balik batas terjauh
                if last.zone_type == "DEMAND":
                    sl_rec = min(last.sl_recommended, z.sl_recommended)
                    inval_p = combined_lo
                else:
                    sl_rec = max(last.sl_recommended, z.sl_recommended)
                    inval_p = combined_hi
                    
                merged[-1] = Zone(
                    zone_id=f"ZONE_{tf_label}_{last.zone_type}_{int(combined_mid)}",
                    symbol=last.symbol,
                    timeframe=tf_label,
                    zone_type=last.zone_type,
                    price_low=round(combined_lo, 2),
                    price_high=round(combined_hi, 2),
                    midpoint=combined_mid,
                    score=best_score,
                    grade=new_grade,
                    origin_bos=last.origin_bos if last.score >= z.score else z.origin_bos,
                    fvg_confirmation=last.fvg_confirmation or z.fvg_confirmation,
                    displacement_strength=max(last.displacement_strength, z.displacement_strength),
                    freshness="FRESH" if (last.freshness == "FRESH" or z.freshness == "FRESH") else "TESTED_1X",
                    touch_count=min(last.touch_count, z.touch_count),
                    liquidity_sweep_status=last.liquidity_sweep_status if last.liquidity_sweep_status != "NONE" else z.liquidity_sweep_status,
                    invalidation_price=round(inval_p, 2),
                    is_valid=True,
                    rejection_reason="",
                    ob_candle_time=last.ob_candle_time,
                    bos_candle_time=last.bos_candle_time,
                    sl_recommended=sl_rec,
                    tp1_recommended=last.tp1_recommended,
                    tp2_recommended=last.tp2_recommended,
                    score_breakdown=last.score_breakdown if last.score >= z.score else z.score_breakdown,
                    merged_from=merged_ids,
                )
                continue
                
        merged.append(z)
        
    return merged


# =============================================================================
# MULTI-TIMEFRAME CONTEXT & BIAS EVALUATION
# =============================================================================

def evaluate_htf_context(frames: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
    """
    Evaluasi multi-timeframe konteks (D1, H4, H1):
    - D1: Konteks struktur besar.
    - H4: Penentuan bias utama dan zona prioritas.
    - H1: Validasi struktur dan kualitas zona.
    - Mendeteksi adanya konflik arah H4 vs H1.
    """
    hasil = {
        "D1": "NETRAL",
        "H4": "NETRAL",
        "H1": "NETRAL",
        "bias_utama": "NETRAL",
        "has_conflict": False,
        "detail": ""
    }
    
    tf_trends = {}
    for tf_name in ("D1", "H4", "H1"):
        if tf_name in frames and frames[tf_name] is not None and len(frames[tf_name]) >= 2 * SWING_N + 1:
            d = frames[tf_name].copy()
            _, trend, _ = detect_market_structure(d, n=SWING_N)
            # Konfirmasi dengan EMA stack
            if "EMA20" not in d.columns:
                d = tambah_indikator(d)
            last = d.iloc[-1]
            ema_trend = 1 if (last["EMA20"] > last["EMA50"] and last["Close"] > last["EMA20"]) else (
                -1 if (last["EMA20"] < last["EMA50"] and last["Close"] < last["EMA20"]) else 0
            )
            
            # Gabungkan struktur dan filter EMA
            combined = trend + ema_trend
            label = "BULLISH" if combined >= 1 else ("BEARISH" if combined <= -1 else "NETRAL")
            tf_trends[tf_name] = label
            hasil[tf_name] = label
            
    h4_bias = tf_trends.get("H4", "NETRAL")
    h1_bias = tf_trends.get("H1", "NETRAL")
    d1_bias = tf_trends.get("D1", "NETRAL")
    
    # Deteksi konflik signifikan antara H4 dan H1
    if (h4_bias == "BULLISH" and h1_bias == "BEARISH") or (h4_bias == "BEARISH" and h1_bias == "BULLISH"):
        hasil["has_conflict"] = True
        hasil["bias_utama"] = "WAIT (KONFLIK H4 vs H1)"
        hasil["detail"] = f"Konflik arah signifikan: H4 {h4_bias} vs H1 {h1_bias}. Kualitas setup diturunkan / disarankan WAIT."
    else:
        hasil["has_conflict"] = False
        hasil["bias_utama"] = h4_bias if h4_bias != "NETRAL" else (h1_bias if h1_bias != "NETRAL" else d1_bias)
        hasil["detail"] = f"Struktur HTF sinkron: D1 {d1_bias}, H4 {h4_bias}, H1 {h1_bias}."
        
    return hasil


# =============================================================================
# ENTRY VALIDATION HELPER (LTF M5 CONFIRMATION)
# =============================================================================

def validate_entry_setup(
    zone: Zone,
    current_price: float,
    df_m5: pd.DataFrame,
    spread_points: float = 0.0,
    is_news_blackout: bool = False
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validasi Entry Presisi M5:
    Zona valid BELUM TENTU berarti boleh entry!
    
    Syarat Wajib Entry:
    1. Harga berada di area zona atau dalam radius pendekatan yang logis (<= 1.5x ATR M5).
    2. M5 harus menunjukkan konfirmasi struktur (BOS/CHoCH atau CISD M5 yang candle-close).
    3. Liquidity sweep atau rejection M5 mendukung skenario.
    4. R:R ke TP1 minimal 1:1.5.
    5. Spread dan kondisi berita aman.
    
    Jika ada satu syarat wajib yang gagal -> WAIT.
    """
    if not zone.is_valid:
        return False, f"WAIT: Zona {zone.zone_id} tidak valid ({zone.rejection_reason})", {}
        
    if is_news_blackout:
        return False, "WAIT: Sedang berada dalam periode blackout berita High-Impact USD", {}
        
    if df_m5 is None or len(df_m5) < 2 * SWING_N + 1:
        return False, "WAIT: Data M5 tidak mencukupi untuk memverifikasi trigger entry", {}
        
    d5 = df_m5.copy()
    if "ATR14" not in d5.columns:
        d5 = tambah_indikator(d5)
        
    atr_m5 = float(d5["ATR14"].iloc[-1])
    
    # 1. Cek posisi harga terhadap zona
    lo, hi = zone.price_low, zone.price_high
    dist_to_zone = 0.0 if lo <= current_price <= hi else (lo - current_price if current_price < lo else current_price - hi)
    max_approach_dist = max(3.0, 1.5 * atr_m5)
    
    if dist_to_zone > max_approach_dist:
        return False, f"WAIT: Harga ({current_price:.2f}) belum mencapai zona {lo:.2f}-{hi:.2f} (jarak {dist_to_zone:.2f} pt > {max_approach_dist:.2f} pt)", {}
        
    # 2. Cek Konfirmasi Struktur M5 (BOS/CHoCH)
    events_m5, trend_m5, swings_m5 = detect_market_structure(d5, n=SWING_N)
    sweeps_m5 = detect_liquidity_sweeps(d5, swings_m5, lookback=25)
    
    arah_target = "bull" if zone.zone_type == "DEMAND" else "bear"
    req_sweep_type = "SWEEP_LOW" if zone.zone_type == "DEMAND" else "SWEEP_HIGH"
    
    # Cari sweep M5 pada 20 candle terakhir
    has_m5_sweep = any(s["type"] == req_sweep_type for s in sweeps_m5[-5:])
    
    # Cari BOS/CHoCH M5 yang searah pada 10 candle terakhir
    recent_m5_events = [e for e in events_m5[-5:] if e["arah"] == arah_target]
    has_m5_structure = len(recent_m5_events) > 0
    
    if not (has_m5_structure or has_m5_sweep):
        return False, f"WAIT: Belum ada konfirmasi M5 (butuh {req_sweep_type} dan/atau {arah_target.upper()} CHoCH/BOS)", {}
        
    # 3. Hitung R:R realistis
    entry_price = current_price
    sl_price = zone.sl_recommended
    risk = abs(entry_price - sl_price)
    
    if risk < 0.5:
        return False, "WAIT: Jarak SL terlalu sempit / tidak realistis", {}
        
    tp1_price = round(entry_price + RR_MIN * risk, 2) if zone.zone_type == "DEMAND" else round(entry_price - RR_MIN * risk, 2)
    tp2_price = round(entry_price + 2.5 * risk, 2) if zone.zone_type == "DEMAND" else round(entry_price - 2.5 * risk, 2)
    
    actual_rr = abs(tp1_price - entry_price) / risk
    if actual_rr < RR_MIN - 1e-4:
        return False, f"WAIT: R:R ke TP1 ({actual_rr:.2f}) tidak memenuhi standar minimum 1:{RR_MIN}", {}
        
    arah_sinyal = "BUY" if zone.zone_type == "DEMAND" else "SELL"
    
    signal_plan = {
        "arah": arah_sinyal,
        "entry_min": min(round(current_price - 0.75, 2), lo),
        "entry_max": max(round(current_price + 0.75, 2), hi),
        "entry_acuan": round(current_price, 2),
        "sl": sl_price,
        "tp1": tp1_price,
        "tp2": tp2_price,
        "rr": round(actual_rr, 2),
        "zone_id": zone.zone_id,
        "timeframe": zone.timeframe,
        "grade": zone.grade,
        "score": zone.score,
        "keterangan": f"Trigger M5 terkonfirmasi di zona {zone.grade} {zone.timeframe} {zone.zone_type} ({lo:.2f}-{hi:.2f})"
    }
    
    return True, f"ENTRY_VALID: Setup {arah_sinyal} di zona {zone.grade} {zone.timeframe} terkonfirmasi", signal_plan


# =============================================================================
# MAIN ZONE SCANNER ENGINE
# =============================================================================

def scan_xauusd_zones(
    frames: Optional[Dict[str, pd.DataFrame]] = None,
    current_price: Optional[float] = None,
    symbol: str = SYMBOL
) -> Dict[str, Any]:
    """
    Mesin Pencari dan Validasi Zona Supply/Demand Python-Only.
    
    Alur Kerja:
    1. Tarik data OHLCV tertutup dari MT5 untuk D1, H4, H1, M30, M5 (bila frames=None).
    2. Analisis HTF Context (D1, H4, H1) & deteksi potensi konflik tren.
    3. Ekstraksi OB, FVG, dan Liquidity Sweep pada H4 dan H1.
    4. Seleksi dan filter kualitas ketat:
       - BOS harus terkonfirmasi candle close.
       - Displacement minimal 1.5x ATR.
       - FVG konfirmasi wajib ada dan overlap harga.
       - Zona yang sudah invalid (tertembus close) atau over-mitigated DIBUANG.
       - Zona terlalu lebar / terlalu sempit DIBUANG.
    5. Scoring berbobot 0 - 100 dan grading (A+, A, B, REJECTED).
    6. Penggabungan zona overlap (Zone Merging).
    7. Audit trail lengkap untuk zona yang ditolak beserta alasannya.
    8. Jika tidak ada zona lolos: kembalikan list kosong + alasan jelas (JANGAN MEMAKSAKAN ZONA).
    """
    output: Dict[str, Any] = {
        "symbol": symbol,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "current_price": current_price,
        "active_zones": [],
        "rejected_zones": [],
        "best_demand": None,
        "best_supply": None,
        "htf_context": {},
        "empty_reason": "",
        "summary_text": "",
    }
    
    # 1. Siapkan data candlestick
    if frames is None:
        if not pastikan_mt5_aktif():
            output["empty_reason"] = "Koneksi ke MetaTrader 5 tidak aktif. Data tidak dapat diambil."
            output["summary_text"] = "MT5 offline — scanner tidak dapat berjalan."
            return output
            
        frames = {}
        for tf_name, (tf_mt5, bars) in TIMEFRAMES.items():
            df_tf = ambil_data(tf_mt5, bars)
            if df_tf is not None and len(df_tf) >= 20:
                frames[tf_name] = tambah_indikator(df_tf)
            else:
                frames[tf_name] = None
                
    # Pastikan data minimum H4 dan H1 tersedia
    if frames.get("H4") is None or len(frames["H4"]) < 2 * SWING_N + 1 or frames.get("H1") is None or len(frames["H1"]) < 2 * SWING_N + 1:
        output["empty_reason"] = "Data candlestick H4 atau H1 tidak mencukupi untuk melakukan analisis SMC."
        output["summary_text"] = "Data H4/H1 belum cukup."
        return output
        
    # Ambil harga referensi live
    if current_price is None:
        if "M5" in frames and frames["M5"] is not None and len(frames["M5"]) > 0:
            current_price = float(frames["M5"]["Close"].iloc[-1])
        else:
            current_price = float(frames["H1"]["Close"].iloc[-1])
    output["current_price"] = current_price
    
    # 2. Evaluasi Konteks HTF
    htf_ctx = evaluate_htf_context(frames)
    output["htf_context"] = htf_ctx
    
    all_valid_zones: List[Zone] = []
    all_rejected_zones: List[Zone] = []
    
    # 3. Pindai Zona pada Timeframe Utama (H4 dan H1)
    for tf_name in ("H4", "H1"):
        df_tf = frames[tf_name]
        if df_tf is None or len(df_tf) < 2 * SWING_N + 1:
            continue
            
        # Struktur, Swings, Sweeps, dan FVG
        events, _, swings = detect_market_structure(df_tf, n=SWING_N)
        sweeps = detect_liquidity_sweeps(df_tf, swings, lookback=40)
        fvgs = detect_fvgs(df_tf, min_atr_mult=MIN_FVG_ATR)
        
        # Ekstraksi Order Block
        valid_obs, rej_obs = detect_order_blocks(
            df=df_tf,
            events=events,
            fvgs=fvgs,
            sweeps=sweeps,
            timeframe=tf_name,
            max_events=8
        )
        
        all_rejected_zones.extend(rej_obs)
        
        # Scoring & Grading untuk kandidat yang lolos syarat wajib
        for z in valid_obs:
            is_aligned = (
                (z.zone_type == "DEMAND" and htf_ctx.get("bias_utama") == "BULLISH") or
                (z.zone_type == "SUPPLY" and htf_ctx.get("bias_utama") == "BEARISH")
            )
            is_netral = htf_ctx.get("bias_utama") in ("NETRAL", "WAIT (KONFLIK H4 vs H1)")
            
            scored_zone = score_zone(z, htf_bias_aligned=is_aligned, htf_is_neutral=is_netral)
            
            # Filter jarak: zona yang terlalu jauh dari harga saat ini (> MAX_ZONE_DISTANCE_ATR) diabaikan
            dist_to_cur = abs(scored_zone.midpoint - current_price)
            atr_tf = float(df_tf["ATR14"].iloc[-1]) if "ATR14" in df_tf.columns else 4.0
            
            if dist_to_cur > MAX_ZONE_DISTANCE_ATR * atr_tf:
                scored_zone.is_valid = False
                scored_zone.rejection_reason = f"Jarak zona ({dist_to_cur:.1f} pt) terlalu jauh dari harga live ({current_price:.2f})"
                all_rejected_zones.append(scored_zone)
                continue
                
            if scored_zone.is_valid and scored_zone.grade in ("A+", "A", "B"):
                all_valid_zones.append(scored_zone)
            else:
                all_rejected_zones.append(scored_zone)
                
    # 4. Penggabungan Zona Overlap (Zone Merging)
    merged_active_zones = merge_overlapping_zones(all_valid_zones)
    
    # Urutkan zona aktif: Grade tertinggi (A+ > A > B) lalu jarak terdekat ke harga
    merged_active_zones.sort(
        key=lambda z: (
            0 if z.grade == "A+" else (1 if z.grade == "A" else 2),
            abs(z.midpoint - current_price)
        )
    )
    
    # 5. Filter Konflik HTF: Jika H4 vs H1 konflik parah, turunkan atau kosongkan zona berisiko
    if htf_ctx.get("has_conflict"):
        # Hanya pertahankan zona A+ dengan konfluensi ganda bila ada konflik HTF
        merged_active_zones = [z for z in merged_active_zones if z.grade == "A+"]
        
    output["active_zones"] = [z.to_dict() for z in merged_active_zones]
    output["rejected_zones"] = [z.to_dict() for z in all_rejected_zones]
    
    # Tentukan Best Demand & Best Supply
    best_demand = next((z for z in merged_active_zones if z.zone_type == "DEMAND"), None)
    best_supply = next((z for z in merged_active_zones if z.zone_type == "SUPPLY"), None)
    
    output["best_demand"] = best_demand.to_dict() if best_demand else None
    output["best_supply"] = best_supply.to_dict() if best_supply else None
    
    # 6. Alasan jika tidak ada zona lolos
    if not merged_active_zones:
        if htf_ctx.get("has_conflict"):
            output["empty_reason"] = "Konflik arah struktur antara H4 dan H1. Tidak ada setup A+ yang memenuhi syarat keamanan."
        elif len(all_rejected_zones) > 0:
            top_rej = all_rejected_zones[0].rejection_reason
            output["empty_reason"] = f"Tidak ada zona yang memenuhi standar mutu teknikal. Alasan penolakan: {top_rej}."
        else:
            output["empty_reason"] = "Tidak ditemukan Order Block fresh H4/H1 dengan displacement memadai & konfirmasi FVG aktif."
            
    # 7. Susun Summary Text untuk audit & tampilan UI / prompt
    summary_lines = [
        "======================================================================",
        f"📊 [PYTHON-ONLY XAUUSD ZONE SCANNER (SMC ENGINE)] — Harga: {current_price:.2f}",
        f"• Konteks HTF: D1 {htf_ctx.get('D1')} | H4 {htf_ctx.get('H4')} | H1 {htf_ctx.get('H1')} -> Bias: [{htf_ctx.get('bias_utama')}]",
        "======================================================================"
    ]
    
    if merged_active_zones:
        summary_lines.append(f"✅ DITEMUKAN {len(merged_active_zones)} ZONA VALID (LOLOS SELEKSI KETAT):")
        for i, z in enumerate(merged_active_zones, 1):
            fvg_st = z.fvg_confirmation.get("status", "N/A") if z.fvg_confirmation else "None"
            summary_lines.append(
                f"  {i}. [{z.grade}] {z.timeframe} {z.zone_type}: {z.price_low:.2f} - {z.price_high:.2f} "
                f"(Mid {z.midpoint:.2f} | Skor {z.score:.1f}/100 | {z.freshness} | FVG: {fvg_st} | "
                f"SL: {z.sl_recommended:.2f} | TP1: {z.tp1_recommended:.2f})"
            )
    else:
        summary_lines.append("🛑 TIDAK ADA ZONA VALID SAAT INI (STATUS: WAIT)")
        summary_lines.append(f"   Alasan: {output['empty_reason']}")
        summary_lines.append("   (Aturan: Dilarang memaksakan entry atau menciptakan zona pengganti saat pasar belum siap)")
        
    summary_lines.append(f"• Total Kandidat Ditolak: {len(all_rejected_zones)} zona")
    if all_rejected_zones:
        summary_lines.append("  Alasan penolakan kandidat teratas:")
        for rz in all_rejected_zones[:3]:
            summary_lines.append(f"  - {rz.timeframe} {rz.zone_type} ({rz.price_low:.2f}-{rz.price_high:.2f}): {rz.rejection_reason}")
            
    summary_lines.append("======================================================================")
    output["summary_text"] = "\n".join(summary_lines)
    
    return output
